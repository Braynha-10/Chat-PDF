import streamlit as st
from utils.pdf_reader import extract_text_from_pdf
from utils.embedder import generate_embeddings
from utils.vector_search import get_similar_chunks

st.title("📄 Chatbot Inteligente para PDFs")
st.markdown("Carregue seus arquivos PDF e faça perguntas sobre o conteúdo.")

uploaded_file = st.file_uploader("Faça upload de um PDF", type="pdf")

if uploaded_file:
    text = extract_text_from_pdf(uploaded_file)
    chunks, embeddings = generate_embeddings(text)

    st.success("PDF processado com sucesso! Você já pode fazer perguntas.")

    query = st.text_input("Faça uma pergunta sobre o conteúdo do PDF:")

    if query:
        response = get_similar_chunks(query, chunks, embeddings)
        st.markdown("### 📌 Resposta baseada no PDF:")
        st.write(response)
