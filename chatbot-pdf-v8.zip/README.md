# 🚀 Chatbot Inteligente Baseado em PDFs com IA Generativa

> **⚠️ Aviso Importante:**  
> Infelizmente, por limitações na minha assinatura de estudante, não consegui acesso a certos recursos necessários para a execução prática deste projeto, como a utilização de serviços de embeddings, vetorização e armazenamento em nuvem, que são funcionalidades avançadas e geralmente associadas a planos pagos.  
> Mesmo assim, busquei compreender toda a lógica do projeto e apresento abaixo um plano detalhado de como ele seria desenvolvido.

[...] (mesmo conteúdo já fornecido anteriormente)
